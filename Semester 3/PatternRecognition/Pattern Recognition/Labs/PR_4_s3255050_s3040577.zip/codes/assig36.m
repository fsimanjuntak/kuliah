u=[0.5 1 0];
v=[0.31 1.51 -0.5];
w=[-1.7 -1.7 -1.7];

load lab3_3_cat1.mat;
load lab3_3_cat2.mat;
load lab3_3_cat3.mat;

data = [x_w1; x_w2; x_w3];

cat_u = KNN(u, 5,  data, [ones(1, 10), 2*ones(1, 10), 3*ones(1, 10)]);
cat_v = KNN(v, 5,  data, [ones(1, 10), 2*ones(1, 10), 3*ones(1, 10)]);
cat_w = KNN(w, 5,  data, [ones(1, 10), 2*ones(1, 10), 3*ones(1, 10)]);

disp(cat_u)
disp(cat_v)
disp(cat_w)
