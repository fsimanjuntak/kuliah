function [W, Error, SavedLambda] = RelevanceLVQ(Data, W, cluster)

% intializing parameters
Examples = length(Data(:,1));
MisclassifiedCount = 0;
Epoches = 20; 
learnrate = 0.01;
previous_error = 0;
constant_error_rate_counter = 0;
% We intialize lambda1 =0.5 and lambda2 = 0.5
% Lambda = [lambda1 lambda2];
Lambda = [0.5 0.5];

% loop epoches
for epoch=1:Epoches
     MisclassifiedCount = 0;
%      we store both the lambda values at each epoch for later use
     SavedLambda(epoch,:) = Lambda;
%     iterate over the datapoints
  for idx=1:Examples
    Instance = Data(idx,1:2);
    class  = Data(idx,3);
%     Ecludean distance and prototype comparision
    for m=1:length(W(:,1))
        x(m,:) = Instance - W(m,:); 
        dist(m) = sqrt(x(m,:)*x(m,:)');
    end
%  The index and distance value of the nearest prototype   
% Update the prototype based on the class label similarity

% we use the equation from the slides to update the
%   relevance learning parameters
 [val ind] = min(dist);
    if class == cluster(ind)
        W(ind,:) = W(ind,:) + learnrate*(x(ind,:).*Lambda);
        Lambda = Lambda + learnrate*(x(ind,:).*Lambda);
    else
        W(ind,:) = W(ind,:) - learnrate*(x(ind,:).*Lambda);
        Lambda = Lambda - learnrate*(x(ind,:).*Lambda);
%         increment the misclassified data points
        MisclassifiedCount = MisclassifiedCount +1;
    end  
    
% we enforce the unity of the Lambda summation and enforce lambda > 0 by
% dividing the individual lambdas by the sum of all the indivdual lambdas
    Lambda = Lambda/sum(Lambda);
    end
       
    %Calculating the error
      current_error = MisclassifiedCount/Examples;
      Error(epoch,:) = current_error;
      
      %If previous error equals to current error
      if (previous_error == current_error)
          constant_error_rate_counter = constant_error_rate_counter+1;
      else
          previous_error = current_error;
          constant_error_rate_counter = 0;
      end
      
      % If the last three error rates are equal, stop the epoch
      if (constant_error_rate_counter == 3)
          break
      end
    end
end
