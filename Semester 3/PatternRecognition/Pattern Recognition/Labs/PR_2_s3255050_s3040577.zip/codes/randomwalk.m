% randomwalk.dat is a file with the output of the C++ program
fileID = fopen('randomwalk.dat', 'r');
data = fscanf(fileID, '%d');
plot(data);
xlabel('Endpoint');
ylabel('Number of players');
title('# of Players ending in a specific endpoint');