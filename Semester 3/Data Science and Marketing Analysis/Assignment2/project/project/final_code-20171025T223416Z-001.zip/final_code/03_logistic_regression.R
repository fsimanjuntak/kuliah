######### LOGIT
BaseFormula1 <- as.formula(IsSale ~ views + carts + abandon + sale + remove+ startyear+ 
                             birthyear+numbersearches+numberitems+avgprice+gender+
                             TG_avg_temp+TG_avg_temp+FG_avg_wind+SQ_sunshine+RH_precipitation+
                             NG_avg_cloud+UG_humidity)


Session_logit <- glm(BaseFormula1 , data = x.train, family = "binomial")

summary(Session_logit)

x.evaluate$predictionlogit <- predict(Session_logit, newdata=x.evaluate, type = "response")
x.evaluate$predictionlogitclass[x.evaluate$predictionlogit>.5] <- "Sale"
x.evaluate$predictionlogitclass[x.evaluate$predictionlogit<=.5] <- "NotSale"

x.evaluate$correctlogit <- x.evaluate$predictionlogitclass == x.evaluate$SaleString
print(paste("% of predicted classifications correct", mean(x.evaluate$correctlogit)))
LogitOutput <- makeLiftPlot(x.evaluate$predictionlogit,x.evaluate,"Logit")

LogitOutput$PercCorrect <- mean(x.evaluate$correctlogit)*100