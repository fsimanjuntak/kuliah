
 X = importdata('data_lvq_A.mat');
 Y = importdata('data_lvq_B.mat');
 A = zeros(length(X(:,1)),1);
 B = ones(length(Y(:,1)),1);
 Data = [X A; Y B];
 color = ['gd' 'yd' 'cd'];
 W1 = [ mean(X(:,1)) mean(X(:,2))];
 W3 = [ mean(Y(:,1)) mean(Y(:,2))];
 W2 = W1;
 W = [W1 ; W2; W3];
 cluster = [0 0 1];

%  We call the RLVQ function to get the new prototypes, the error rate and
%  the bothe the lambda values
 [WNew Error SavedLambda] = RelevanceLVQ(Data,W, cluster);

%  The following code plots a scatter plot of the points and the final
%  positions of the prototypes
 figure(1);
     scatter(X(:,1),X(:,2), [], 'blue');
     hold on;
     scatter(Y(:,1),Y(:,2), [], 'red');
     for i=1:3
     scatter(WNew(i,1),WNew(i,2), [], 'filled', color(i));
     end
     hold off;

%  In order to plot the learning error rate and the lmbda values across the
%  epoches
   figure(2);
   subplot(1,2,1);
   plot(Error);
   subplot(1,2,2);
   plot(SavedLambda(:,1));
   hold on;
   plot(SavedLambda(:,2));