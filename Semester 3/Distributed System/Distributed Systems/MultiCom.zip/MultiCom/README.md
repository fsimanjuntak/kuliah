MultiCom
========

This project allows different users to write text simultaneously on different computers.
