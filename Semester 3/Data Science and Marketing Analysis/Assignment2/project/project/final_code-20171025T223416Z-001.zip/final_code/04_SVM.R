############ SVM
library(e1071)
Session_SVM <- svm(BaseFormula , data = x.train, probability=T)
summary(Session_SVM)

x.evaluate$predictionSVM <- predict(Session_SVM, newdata=x.evaluate, probability = T)

x.evaluate$correctSVM <- x.evaluate$predictionSVM == x.evaluate$SaleString
print(paste("% of predicted classifications correct", mean(x.evaluate$correctSVM)))

# Extract the class probabilities.
x.evaluate$probabilitiesSVM <- attr(x.evaluate$predictionSVM,"probabilities")[,2]

SVMOutput <- makeLiftPlot(x.evaluate$probabilitiesSVM,x.evaluate,"SVM")