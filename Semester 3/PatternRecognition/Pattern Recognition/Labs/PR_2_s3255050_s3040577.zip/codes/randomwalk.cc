#include <iostream>
#include <cstdio>
#include <cstring>
#include <stdlib.h>     /* srand, rand */
#include <time.h>       /* time */
using namespace std;

typedef unsigned int uint;

const uint N_PEOPLE = 1000000;
const uint N_TURNS = 100;

uint endpoints[N_TURNS];

int main() {
    memset(endpoints, 0, N_TURNS); // Set all initial positions to 0

    srand(time(NULL));

    // Every player plays 100 turns
    for (uint player = 0; player < N_PEOPLE; ++player) {
        uint current_endpoint = 0;

        for (uint turn = 0; turn < N_TURNS; ++turn)
            current_endpoint += rand() & 1; // Add random bit

        ++endpoints[current_endpoint]; // Increment the # of ppl ending here
    }

    for (uint turn = 0; turn < N_TURNS; ++turn)
        cout << endpoints[turn] << endl;
}
